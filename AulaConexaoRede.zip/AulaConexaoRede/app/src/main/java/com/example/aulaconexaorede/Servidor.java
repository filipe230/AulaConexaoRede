package com.example.aulaconexaorede;

public class Servidor {
}
